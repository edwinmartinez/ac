/**
 * ES lang variables
 * 
 * Authors : Eneko Castresana Vara
 * Last Updated : July 14, 2006
 * TinyMCE Version : 2.0.6.1
 */

tinyMCE.addToLang('layer',{
insertlayer_desc : 'Insertar nueva capa',
forward_desc : 'Adelante',
backward_desc : 'Atr&aacute;s',
absolute_desc : 'Posicionamiento absoluto',
content : 'Nueva capa...'
});
